//Group makabaka
//Lee Lai Queen A23CS0100
//Wong Shi Yun A23CS0198
//Chen Shu Yan A23CS0059

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#define LIM 5

class Book {
    protected: 
        int bookID;
        string title;
        string publisher;
        int publicationYear;
        string ISBN;
        string condition;
        string status;

    public:
        Book(int ID=0, string tt="", string ps="", int py=0, string con="", string isbn="") {
            bookID = ID;
            title = tt;
            publisher = ps;
            publicationYear = py;
            condition = con;
            ISBN = isbn;
            status = "Available";
        }

        virtual ~Book() {}

        virtual void dispBookDetails() const {
            cout << setw(11) << setprecision(6) << bookID
                << setw(20) << title
                << setw(13) << publisher
                << setw(8) << publicationYear
                << setw(15) << ISBN
                << setw(15) << condition
                << setw(15) << status;
        }

        void changeStatus(){
            if (status == "Available") {
                status = "Unavailable";
            }else {
                status = "Available";
            }
        }

        int getID() const {return bookID;}
        string getTitle() const {return title;}
        string getPS() const {return publisher;}
        int getPY() const {return publicationYear;}
        string getISBN() const {return ISBN;}
        string getCon() const {return condition;}
        string getStat() const {return status;}
        virtual string getAut() const {return "";}
        virtual string getLang() const{return "";}

        void setTitle(string t) {
            title = t;
        }
        void setPS(string ps) {
            publisher = ps;
        }
        void setPY(int py) {
            publicationYear = py;
        }
        void setISBN(string isbn) {
            ISBN = isbn;
        }
        void setCon(string c) {
            condition = c;
        }
        void setStat(string s) {
            if (s == "A") {
                status = "Available";
            }else{
                status == "Unavailable";
            }
        }
        void setID(int id){
            bookID = id;
        }

        virtual void setAut(string) {}
        virtual void setLang(string) {}

        friend class User;

};


class Dictionary: public Book {
    private:
        string pair_language;
        string authorTeam;

    public:
        Dictionary(int ID=0, string tt="", string ps="", int py=0, string con="", string isbn="", string auT="", string pl=""): Book(ID, tt, ps, py, con, isbn) {
            pair_language = pl;
            authorTeam = auT;
        }

        ~Dictionary() {}

        string getLang() const override {return pair_language;}
        string getAut() const override {return authorTeam;}

        void dispBookDetails() const override {
            Book::dispBookDetails();
            cout << setw(15) << authorTeam
                 << setw(15) << pair_language
                 << endl;
        }
        void setAut(string a){authorTeam = a;}
        void setLang(string l) {pair_language = l;}
};


class Encyclopedia: public Book {
    private: 
        string author;
        string language;

    public:
        Encyclopedia(int ID=0, string tt="", string ps="", int py=0, string con="", string isbn="", string aut="", string lang=""): Book(ID, tt, ps, py, con, isbn) {
            author = aut;
            language = lang;
        }

        ~Encyclopedia() {}

        string getAut() const override {return author;}
        string getLang() const override {return language;}
        void setAut(string a){author = a;}
        void setLang(string l) {language = l;}

        void dispBookDetails() const override {
            Book::dispBookDetails();
            cout << setw(15) << author
                 << setw(15) << language
                 << endl;
        }
};

class PersonalInfo {
    protected:
        string username;
        string email;
        string address;
        string phoneNum;
    
    public:
        PersonalInfo(string un="", string em="", string add="", string phone="") {
            username = un;
            email = em;
            address = add;
            phoneNum = phone;
        }

        string getUsername() {return username;}
        string getEmail() {return email;}
        string getAdd() {return address;}
        string getPhone() {return phoneNum;}

        void setUsername(string un) {username = un;}
        void setEmail(string em) {email = em;}
        void setAdd(string ad) {address = ad;}
        void setPhone(string ph) {phoneNum = ph;}

        void disProfile() const {
            cout << left << setw(20) << "Username:" << username << endl
                 << left << setw(20) << "Email: " << email << endl
                 << left << setw(20) << "Address: " << address << endl
                 << left << setw(20) << "Phone Num: " << phoneNum << endl;
        }

        void updateProfile() {
            int option;

            cout << ">>> UPDATE PROFILE INFO <<<" << endl;
            cout << "\nYou are only allowed to update the following information.\n";
            cout << "1. Update username " << endl
                 << "2. Update email " << endl
                 << "3. Update address " << endl
                 << "4. Update phone number " << endl;
            cout << "Enter desired category to update (1-4): ";
            cin >> option;

            if (option == 1){
                cout << "\nEnter new username: ";
                cin >> username;
            }else if (option ==2){
                cout << "\nEnter new email: ";
                cin >> email;
            }else if (option == 3){
                cin.ignore();
                cout << "\nEnter new address: ";
                getline(cin,address);
            }else if (option == 4){
                cout << "\nEnter new phone number: ";
                cin >> phoneNum;
            }else{
                throw "**Invalid option number";
            }
        }

    friend class User;
};


class Review {
    private:
        string comment;
        int _bookID;
    
    public:
        Review(int id=0, string c=""): _bookID(id), comment(c) {}

        void setReview() {
            cout << "Enter book ID: ";
            cin >> _bookID;
            cout << "Write your review: ";
            getline(cin, comment);
        }

        string getReview(){
            return comment;
        }
};

class Wishlist {
    private:
        int wishID;
        string wishBook;
    
    public:
        Wishlist(int id=0, string wb=""): wishID(id), wishBook(wb) {}

        void dispWishBook() {
            cout << setw(11) << wishID
                 << setw(20) << wishBook << endl;
        }

        int getID() {return wishID;}
        string getWBook() {return wishBook;}

        void setID(int id) {
            wishID = id;
        }
        void setWBook(string b) {
            wishBook = b;
        }

        friend class User;
};

class User {
    protected: 
        int userID;
        string password;
        PersonalInfo pI;
        Book **owned;
        Book **exchanged;
        Review *re;
        Wishlist *wish;
    
    public: 
        int booknum;
        int wishnum;
        int exnum;

        User(int ID=-1, string pass="", PersonalInfo _pI = PersonalInfo()){
            userID = ID;
            password = pass;
            pI = _pI;
            owned = NULL;
            re = NULL;
            wish = NULL;
            booknum = 0;
            wishnum = 0;
            exnum = 0;
            owned = new Book*[LIM];

            for (int i = 0; i < LIM; ++i) {
                owned[i] = nullptr; // Initialize array elements to nullptr
            }

            exchanged = new Book*[LIM];
            re = new Review[LIM];
            wish = new Wishlist[LIM];
        }

        ~User() {
            delete[] owned;
            delete[] exchanged;
            delete[] re;
            delete[] wish;
        }

        void setPass(string p) {
            password = p;
        }
        

        void dispBookList() {
            for (int i=0; i < booknum; i++){
                owned[i]->dispBookDetails();
            }      
            
        }

        void updateBookInfo() {
            int temp;
            int select;

            cout << "Enter book ID to update book info: ";
            cin >> temp;

            for (int i=0; i<booknum; i++){
                if (temp == owned[i]->getID()){
                    select = i;
                    int opup;
                    string New;
                    int NNew;
                    cout << "1. Update book title\n"
                         << "2. Update publisher\n"
                         << "3. Update publish year\n"
                         << "4. Update author\n"
                         << "5. Update language\n"
                         << "6. Update condition\n"
                         << "7. Update status\n";
                    cout << "Enter book detail option to update: ";
                    cin >> opup;

                    if (opup == 1){
                        cin.ignore();
                        cout << "Enter new title: ";
                        getline(cin,New);
                        owned[select]->setTitle(New); 
                        cout << "Book #" << temp << " succefully updated.\n";
                        

                    }else if (opup == 2){
                        cout << "Enter new publisher: ";
                        cin.ignore();
                        getline(cin,New);
                        owned[select]->setPS(New); 
                        cout << "Book #" << temp << " succefully updated.\n";

                    }else if (opup == 3){
                        cout << "Enter new publication year: ";
                        cin >> NNew;
                        owned[select]->setPY(NNew); 
                        cout << "Book #" << temp << " succefully updated.\n";
                    
                    }else if (opup == 4){
                        cin.ignore();
                        cout << "Enter new author: ";
                        getline(cin,New);
                        owned[select]->setAut(New); 
                        cout << "Book #" << temp << " succefully updated.\n";
                    
                    }else if (opup == 5){
                        cin.ignore();
                        cout << "Enter new language or pair language: ";
                        getline(cin,New);
                        owned[select]->setLang(New);
                        cout << "Book #" << temp << " succefully updated.\n";
                    
                    }else if (opup == 6){
                        cin.ignore();
                        cout << "Enter latest condition: ";
                        getline(cin,New);
                        owned[select]->setCon(New);
                        cout << "Book #" << temp << " succefully updated.\n";
                    
                    }else if (opup == 7){
                        cin.ignore();
                        owned[select]->changeStatus();
                        cout << "Book #" << temp << "succefully updated.\n";
                    
                    }else{
                        cout << "**Invalid update option" << endl;
                    }
                }else{
                    cout << "\nYou don't own this book.\n";
                }
            }

        }

        void removeBook() {
            int del;
            int s = -1;
            cout << "Enter book ID to remove: ";
            cin >> del;
            for (int i=0; i<booknum; i++){
                if (del == owned[i]->getID()){
                        s = i;
                        break;
                }
            }
            if (s != -1){
                for (int i=s; s<booknum; s++){
                    owned[i] = owned[i+1];
                }
                booknum -= 1;
                cout << "Book #" << del << " removed from owned book list\n";
            }else{
                cout << "You do not own this book.\n";
            }
        }

        void addBook(int count){

            if (booknum > LIM) {
                cout << "Book capacity reached.\n";
                return;
            }

            int type;
            string tempT,tempA,tempL,tempC,tempPS,tempISBN;
            int tempPY;

            cout << "Is your book a dictionary (1) or encyclopedia (2)?  ";
            cin >> type;
            cin.ignore();

            if (type == 1){
                owned[booknum] = new Dictionary(count);
            }else{
                owned[booknum] = new Encyclopedia(count);
            }

            cout << "Enter new book title: ";
            getline(cin,tempT);
            owned[booknum]->setTitle(tempT);

            cout << "Enter new book author: ";
            getline(cin,tempA);
            owned[booknum]->setAut(tempA);

            cout << "Enter new book language: ";
            cin >> tempL;
            owned[booknum]->setLang(tempL);

            cout << "Enter publisher: ";
            cin >> tempPS;
            owned[booknum]->setPS(tempPS);

            cout << "Enter publisher year: ";
            cin >> tempPY;
            owned[booknum]->setPY(tempPY);
            cin.ignore();

            cout << "Enter ISBN code: ";
            cin >> tempISBN;
            owned[booknum]->setISBN(tempISBN);

            cout << "Enter new book condition: ";
            cin.ignore();
            getline(cin,tempC);
            owned[booknum]->setCon(tempC);
            owned[booknum]->setStat("Available");
            booknum++;
            
            cout << "New book successfully added.\n";
        
        }


        void exchange(Book *a){
            exchanged[exnum] = a;
            exnum++;
        }

        void addReview() {

            if (exnum == 0) {
                string x;
                cout << "\nYou have not exchanged any book yet.\n";
                return;
            }
            
            int ID;
            string temp;
            cout << "\nEnter book ID of desired book to review: ";
            cin >> ID;

            for (int i=0; i<exnum; i++){
                if (ID == exchanged[i]->getID()){
                        cin.ignore();
                        cout << "Write your review: ";
                        getline(cin,temp);
                        exchanged[i]->setCon(temp);
                        dispEx();
                }else{
                    cout << "You are not allowed to review books that you have not exchanged.\n";
                }
            }
        }

        void dispEx() {
            cout << "\n>>> EXCHANGE BOOK LIST <<<\n";
            cout << setw(11) << "Book ID"
                     << setw(20) << "Title"
                     << setw(13) << "Publisher"
                     << setw(8) << "Year"
                     << setw(15) << "ISBN"
                     << setw(15) << "Condition" 
                     << setw(15) << "Status" 
                     << setw(15) << "Author"
                     << setw(15) << "Language" << endl;
            for (int i=0;i<exnum;i++){
                exchanged[i]->dispBookDetails();
            }
        }

        void updateWishList(int num) {
                char op;
                int del;
                cout << "\nWould you like to delete any book from your wishlist? (Y/N) ";
                cin >> op;

                if (op == 'Y'){
                    cout << "Enter book ID to delete: ";
                    cin >> del;

                    for (int i=0; i<wishnum; i++){
                        if (del == wish[i].getID()){
                            for (int i=0; i<wishnum; i++){
                                wish[i] = wish[i+1];
                            }
                            wishnum --;
                            break;
                        }
                    }
                }else{
                    return;
                }
        }

        void disWish(){
            cout << "\n>>> CURRENT WISHLIST <<<\n";
            cout << setw(11) << "Book ID" 
                 << setw(20) << "Title" << endl;
            for (int i=0;i<wishnum;i++){
                wish[i].dispWishBook();
            }
        }

        void disUser() const {
            cout << left << setw(20) << "User ID : " << userID << endl;
            cout << left << setw(20) << "Password: " << password << endl << endl;
            pI.disProfile();
            cout << endl;
        }


        void addWishBook(Book a) {
            wish[wishnum].setID(a.getID());
            wish[wishnum].setWBook(a.getTitle());
            wishnum++;
        }

        int getID() {return userID;}
        string getPass() {return password;}
        string getUN() {return pI.getUsername();}
        string getEM() {return pI.getEmail();}
        string getAD() {return pI.getAdd();}
        string getPH() {return pI.getPhone();}
        Book * getOwned() {return *owned;}

        void updateP() {
            try{
                pI.updateProfile();
            } 
            catch (const char* mesg){
                cout << mesg;
            }
        }
        void setOwned(Book* b) {
            if (booknum < LIM) {
                owned[booknum++] = b;
            } else {
                cout << "Book Limit reached\n" << endl;
            }
        }

};

class Student: public User {
    private:
        string edulvl;
        string eduIns;
    
    public:
        Student(int id=-1, string pass="", PersonalInfo pI=PersonalInfo(), string lvl="", string ins=""): User(id,pass,pI){
            edulvl = lvl;
            eduIns = ins;
        }

        ~Student() {}

        void seteduLvl(string lvl) {
            edulvl = lvl;
        }

        void seteduIns(string ins) {
            eduIns = ins;
        }

        string getEduLvl() {return edulvl;}
        string getEduIns() {return eduIns;}
};

class NonStudent: public User {
    private: 
        string job;
        string field;

    public:
        NonStudent(int id=0, string pass="", PersonalInfo pI=PersonalInfo(), string j="", string f=""): User(id, pass, pI) {
            job = j;
            field = f;
        }

         ~NonStudent() {}

        void setJob(string j) {
            job = j;
        }

        void setField(string f) {
            field = f;
        }

        string getJob() {return job;}
        string getField() {return field;}
        
};

void printHeader() {
    cout << "\n"
         << setw(11) << "Book ID" 
         << setw(20) << "Title" 
         << setw(13) << "Publisher" 
         << setw(8) << "Year" 
         << setw(15) << "ISBN" 
         << setw(15) << "Condition" 
         << setw(15) << "Status" 
         << setw(15) << "Author" 
         << setw(15) << "Language" << endl;
}

void exitM() {
    cout << "\nPress any number to return to main menu.\n";
    cout << "Press 6 to exit.                           "; 
}

int main() {

    int ucount = 0; //total user count
    User* allUser[10];
    for (int i = 0; i < 10; ++i) {
        allUser[i] = new User();
    }

    int user_i;  //current user index
    int bcount = 0; //total book count

    //initial users 
    Student s1 = {ucount,"hey",{"Ahmad","ahmad@123.com","Jalan Raya","0126123548"},"University","UTM"};
    allUser[ucount++]=&s1;
    NonStudent n1 = {ucount,"HEY",{"Ali","ali@123.com","Jalan Maju","01256985"},"Teacher","Science"};
    allUser[ucount++]=&n1;


    //initial books
    Encyclopedia* b1 = new Encyclopedia{bcount++,"Science Book","Pelangi",2024,"Brand new","2024152634","Mohamed Ali","English"};
    Dictionary* b2 = new Dictionary{bcount++,"Chinese Dictionary","Oxford",2012,"Old","589658654","John Wong","Chinese-English"};
    
    
    allUser[s1.getID()]->setOwned(b1);
    allUser[n1.getID()]->setOwned(b2);
    
    

    //login
    string tempName;
    string tempPass;
    
    
    char existYN;
    cout << "Do you have an existing account? (Y/N)  ";
    cin >> existYN;
    cin.ignore();

    if (existYN == 'N') {
        cout << "\n>>> CREATE NEW ACCOUNT <<<\n";

        string uname, email, add, phoneN, pass;
        cout << "Enter new username: ";
        cin >> uname; //one word, no space
        cout << "Enter email: ";
        cin >> email; //one word, no space
        cin.ignore();
        cout << "Enter current address: ";
        getline(cin, add);
        cout << "Enter phone number: ";
        cin >> phoneN; //one word, no space
        cout << "Set password: ";
        cin >> pass; //one word, no space
        PersonalInfo p(uname, email, add, phoneN);

        char s;
        cout << "\nAre you a student? (Y/N)  ";
        cin >> s;
        cin.ignore(); // Clear newline character from buffer

        if (s == 'Y') {
            string lvl, ins;
            cout << "Enter education level: ";
            getline(cin, lvl);
            cout << "Enter education institution: ";
            getline(cin, ins);
            Student s(ucount, pass, p, lvl, ins);
            allUser[ucount++] = &s;
            existYN = 'Y';

        } else {
            string job, field;
            cout << "Enter job: ";
            getline(cin, job);
            cout << "Enter interested field: ";
            getline(cin, field);

            NonStudent n(ucount, pass, p, job, field);
            allUser[ucount++] = &n;
            existYN = 'Y';
        }
    }
        
    cout << endl << ">>> LOGIN <<<" << endl;
    cout << "Username: ";
    getline(cin, tempName);

    cout << "Password: ";
    getline(cin, tempPass);

    int unfound=0;
    for (int i=0; i<ucount; i++){
        if (tempName == allUser[i]->getUN()){
            if (tempPass == allUser[i]->getPass()) {
                cout << "Login successful! \n";
                user_i = i;
            }else{
                cout << "Wrong password\n";
                return 0;
            }
        }else{
            unfound++;
        }
    }
    if (unfound >= ucount){
        cout << "Wrong username\n";
        return 0;
    }
        
    
    

    //menu
    int option = 0;  //0 = menu

    while (option != 6) {
        cout << "\n>>> MENU <<< \n";
        cout << "Option 1. Update profile\n"
             << "Option 2. Explore book listing\n"
             << "Option 3. Update owned book listing\n"
             << "Option 4. Review book\n"
             << "Option 5. Check wishlist\n"
             << "Option 6. EXIT\n";
        cout << "Press option 1-6 to proceed: ";
        cin >> option;

        //update profile
        if (option == 1) {
            cout << "\n>>> CURRENT PROFILE <<<\n";
            allUser[user_i]->disUser();
            
            cout << "\n";
            allUser[user_i]->updateP();
            

            cout << "\n\n >>> NEWEST PROFILE <<<\n";
            allUser[user_i]->disUser();

            exitM();
            cin >> option;
        }

        //explore book
        else if (option == 2) {
            int opEx;
            int seeID;
            bool contx = 1;

            while (contx){
                cout << "\n>>> EXPLORE BOOKS <<<\n";
                printHeader();
                for (int i=0; i<ucount; i++){
                    allUser[i]->dispBookList();
                }

                cout << endl;
                cout << "Enter book ID to see details or press -1 to search or press -2 to exit explore page: ";
                cin >> opEx;

                if (opEx == -2){
                    contx = 0;
                    break;

                }else if (opEx == -1){
                    string search;
                    cout << "Enter ONE search keyword for title: ";
                    cin >> search;

                    printHeader();

                    bool foundAny = 0;
                    for (int i=0; i<ucount; i++){
                        for (int j=0; j<allUser[i]->booknum; j++){
                            int found = allUser[i]->getOwned()[j].getTitle().find(search);
                            if (found != std::string::npos){
                            allUser[i]->getOwned()[j].dispBookDetails(); 
                            foundAny = 1;
                            }
                        }
                    }

                    if (foundAny == 0) {
                        seeID = -3;
                        cout << "\n**No result found.\n";
                    }else{
                        cout << "\nEnter book ID to see details: ";
                        cin >> seeID;
                    }
                    
                }else{
                    seeID = opEx;
                }

                if (seeID != -3){
                    for (int i=0; i<ucount; i++){
                        for (int j=0; j<allUser[i]->booknum; j++){
                            if (seeID == allUser[i]->getOwned()[j].getID()){
                                cout << "\n>>> BOOK DETAILS <<<\n";
                                cout << left << setw(11) << "Book ID: " << allUser[i]->getOwned()->getID() << endl;
                                cout << left << setw(11) << "Title: " << allUser[i]->getOwned()->getTitle() << endl;
                                cout << left << setw(11) << "Author: " << allUser[i]->getOwned()->getAut() << endl;
                                cout << left << setw(11) << "Language: " << allUser[i]->getOwned()->getLang() << endl;
                                cout << left << setw(11) << "Condition: " << allUser[i]->getOwned()->getCon() << endl;
                                cout << left << setw(11) << "Status: " << allUser[i]->getOwned()->getStat() << endl;

                                if (allUser[i]->getOwned()[j].getStat() == "Available"){
                                    char req;
                                    cout << "\nWould you like to send exchange request (Y/N)?  ";  
                                    cin >> req; 

                                    if (req == 'Y'){
                                        allUser[i]->getOwned()[j].changeStatus();
                                        allUser[user_i]->exchange(&allUser[i]->getOwned()[j]);
                                        cout << "Exchange request successfully sent!\n";
                                    }
                                    break;

                                }else{
                                    char wi;
                                    cout << "\nWould you like to add into wishlist (Y/N)?  ";
                                    cin >> wi;
                                    
                                    if (wi == 'Y'){
                                        allUser[user_i]->addWishBook(allUser[i]->getOwned()[j]);
                                        cout << "New book successfully added to wishlist!\n";
                                    }

                                    break;
                                }
                            }
                        }
                        
                    }
                }
            }
            exitM();
            cin >> option;
        }
        
        //update owned book
        else if (option == 3){
            int opUp;
            bool conty = 1;

            while (conty){

                cout << "\n>>> CURRENT OWNED BOOK LISTING <<<\n";
                printHeader();
                allUser[user_i]->dispBookList();

                cout << "\n>>> UPDATE BOOK LISTING <<<" << endl;
                cout << "Choose among options below\n";
                cout << "1. Update owned books\n";
                cout << "2. Add new book\n";
                cout << "3. Remove book\n";
                cout << "4. Return to main menu\n";
                cout << "Enter update option: ";
                cin >> opUp;
                cout << endl;

                if (opUp == 1){
                    allUser[user_i]->updateBookInfo();
                }else if (opUp == 2){
                    allUser[user_i]->addBook(bcount++);
                }else if (opUp == 3){
                    allUser[user_i]->removeBook();
                    bcount--;
                }else if (opUp == 4){
                    conty = 0;
                    break;
                }
                else{
                    cout << "**Invalid option choice\n";
                }
            }

            exitM();
            cin >> option;
        }
        
        //review book
        else if (option == 4){
            allUser[user_i]->dispEx();
            allUser[user_i]->addReview();
            exitM();
            cin >> option;
        }

        //display wishlist 
        else if (option == 5){
            cout << "\n>>> CHECK WISHLIST <<<\n";
            allUser[user_i]->disWish();
            cout << endl;
            allUser[user_i]->updateWishList(bcount);
            cout << endl;
            allUser[user_i]->disWish();

            exitM();
            cin >> option;
        }
        
        //exit
        else if (option == 6){
            cout << "\nThank you for visiting.";
            return 0;
        }
        
        else{
            cout << "**Invalid option!";
        }
        
    }

}
