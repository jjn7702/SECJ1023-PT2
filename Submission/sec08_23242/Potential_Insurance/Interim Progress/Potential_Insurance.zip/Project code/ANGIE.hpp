#ifndef ANGIE_HPP
#define ANGIE_HPP

#include "TANJIAYING.hpp"
#include <iostream>
using namespace std;

class City {
protected:
    int postcode;
    string cityName;

public:
    // Default constructor
    City() : postcode(0), cityName("") {}

    // Parameterized constructor
    City(int pc, string cn) : postcode(pc), cityName(cn) {}

    // Getter for postcode
    int getPostcode() {
        return postcode;
    }

    // Setter for postcode
    void setPostcode(int pc) {
        postcode = pc;
    }

    // Getter for cityName
    string getCityName(){
        return cityName;
    }

    // Setter for cityName
    void setCityName(string cn) {
        cityName = cn;
    }
};

class UserManager {
public:
    City cities[10];

    UserManager() {
        cities[0] = City(0, "batu pahat");
        cities[1] = City(0, "johor bahru");
        cities[2] = City(0, "kluang");
        cities[3] = City(0, "kota tinggi");
        cities[4] = City(0, "kulai");
        cities[5] = City(0, "mersing");
        cities[6] = City(0, "muar");
        cities[7] = City(0, "pontian");
        cities[8] = City(0, "segamat");
        cities[9] = City(0, "tangkak");
    }

    City* getCity(int index) {
        if (index >= 0 && index < 10) {
            return &cities[index];
        }
        return nullptr;
    }
};

class Address {
public:
    string unit;
    string road;
    City *city;
    
    Address():unit(""),road(""){city = {};}
    Address(string u, string r, City *c) : 
    unit(u), road(r), city(c){}
   
    void setAddress(string u, string r, City *c) {
        unit = u;
        road = r;
        city = c;
    }

    string getUnit() {
        return unit;
    }

    string getRoad() {
        return road;
    }

    string getcity(){
        return city->getCityName();
    }

    void displayAddress(){
        cout << "Unit: " << unit << endl;
        cout << "Road: " << road << endl;
        cout << "City: " << city->getCityName() << endl;
        cout << "Postcode: " << city->getPostcode() << endl;
    }
};

class User {
private:
    string username;
    string password;
    string name;
    Address address;
    Member *member;
    bool isMember;

public:
    User() : isMember(false) {}
    User(string un, string pw, string n, Address a) 
        : username(un), password(pw), name(n), address(a), isMember(false) {}

    void setUsername(string un) {
        username = un;
    }

    void setPassword(string pw) {
        password = pw;
    }

    void setName(string n) {
        name = n;
    }

    void setAddress(Address a) {
        address = a;
    }

    void setMemberStatus(bool status) {
        isMember = status;
    }

    void displayUserInfo() {
        cout << "Username: " << username << endl;
        cout << "Name: " << name << endl;
        cout << "Address: ";
        address.displayAddress();
        //display memberinfo
        if(isMember)
            cout << "You are our member\n";
        else
            cout << "Welcome to subscribe our member for great discount!\n";
    }
    
    void setMember(Member *m) {
        member = m;
    }

    Member getMember() const {
        return *member;
    }

    bool getIsMember() const {
        return isMember;
    }

    string getUsername() {
        return username;
    }

    string getPassword() {
        return password;
    }

    string getCity(){
        return address.getcity();
    }
};

//done
void signUp(User users[], int& userCount, UserManager& userManager) {
    string username, password, confirmPassword, name, unit, road;
    int postcode;
    int cityChoice;

    cout << "Create a username: ";
    cin >> username;
    cout << "Create new password(at least 8 character): ";
    cin >> password;
    cout << "Please confirm your password: ";
    cin >> confirmPassword;

    while (password != confirmPassword) {
        cout << "Passwords do not match. Please try again.\n";
        cout << "Create new password: ";
        cin >> password;
        cout << "Please confirm your password: ";
        cin >> confirmPassword;
    }

    while (password.length() < 8) {
        cout << "Passwords is too short. Please try again.\n";
        cout << "Create new password: ";
        cin >> password;
        cout << "Please confirm your password: ";
        cin >> confirmPassword;
    }

    cout << "Please fill the basic information\n";
    cout << "Name: ";
    cin.ignore();
    getline(cin, name);
    cout << "Address unit: ";
    getline(cin, unit);
    cout << "Road: ";
    getline(cin, road);
    cout << "City\n";
    for (int i = 0; i < 10; ++i) {
        cout << i + 1 << ": " << userManager.cities[i].getCityName() << endl;
    }
    cout << "Your city No: ";
    cin >> cityChoice;
    cout << "Postcode: ";
    cin >> postcode;
    cout << "The system will refresh to update your information....\n\n";

    City* selectedCity = userManager.getCity(cityChoice - 1);
    selectedCity->setPostcode(postcode);
    if (selectedCity != nullptr) {
        users[userCount++] = User(username, password, name, Address(unit, road, selectedCity));
    }
}

void updateUserInfo(User & user, User users[], int userCount, City cities[]) {
    string newUsername, newName, newPassword,newConfirmPassword, newUnit, newRoad;
    int newCityChoice,newPostcode;

    cout << "New username: ";
    cin.ignore();
    cin >> newUsername;
    cout << "New name: ";
    cin >> newName;
    cout << "New password: (at least 8 characters) ";
    cin >> newPassword;
    cout << "Please confirm your password: ";
        cin >> newConfirmPassword;
    while (newPassword!= newConfirmPassword) {
        cout << "Passwords do not match. Please try again.\n";
        cout << "New password: (at least 8 characters) ";
        cin >> newPassword;
        cout << "Please confirm your password: ";
        cin >> newConfirmPassword;
    }

    while (newPassword.length() < 8) {
        cout << "Passwords is too short. Please try again.\n";
        cout << "New password: (at least 8 characters)";
        cin >> newPassword;
        cout << "Please confirm your password: ";
        cin >> newConfirmPassword;
    }

    cout << "New address: \n";
    cout << "----------------------------------------------------------------\n";
    for (int i = 0; i < 10; ++i) {
        cout << i + 1 << ": " << cities[i].getCityName() << endl;
    }
    cout << "New city(1-10): ";
    cin >> newCityChoice;
    cout << "Updated city: " << cities[newCityChoice - 1].getCityName() << endl;
    cout << "New postcode: ";
    cin >> newPostcode;
    cin.ignore();
    cout << "New unit: ";
    getline(cin, newUnit);
    cout << "New road: ";
    getline(cin, newRoad);
    cout << "Your information will be updated when u login again....\n\n";
	
    
    cities[newCityChoice-1].setPostcode(newPostcode);
    Address newAddress(newUnit, newRoad, &cities[newCityChoice - 1]);
    
    

    

    // Update the login credentials if the current user is the same user being updated
    for (int i = 0; i < userCount; ++i) {
        if (users[i].getUsername() == user.getUsername()) {
            users[i].setUsername(newUsername);
            users[i].setName(newName);
            users[i].setPassword(newPassword);
            users[i].setAddress(newAddress);
            break;
        }
    }
}

bool login(User users[], int userCount, User& currentUser) {
    string username, password;
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    for (int i = 0; i < userCount; ++i) {
        if (users[i].getUsername() == username && users[i].getPassword() == password) {
            currentUser = users[i];
            return true;
        }
    }
    return false;
}

//done by TAN JIA YING
void memberSubscription(User & user) {
    int planChoice;
    cout << "Member subscription plan\n";
    cout << "1) 1 month -> RM4\n";
    cout << "2) 3 months -> RM11\n";
    cout << "3) 1 year -> RM45\n";
    cout << "Choose your plan : ";
    cin >> planChoice;

    double price;
    string period;
    Date startDate, expiryDate;

    int startDay, startMonth, startYear;
    cout << "Today date (day month year): ";
    cin >> startDay >> startMonth >> startYear;
    startDate.setDate(startDay, startMonth, startYear);
    
    switch (planChoice) {
        case 1:
            price = 4.0;
            period = "1 month";
            expiryDate.setDate(startDay, startMonth + 1, startYear);
            if (startMonth + 1 > 12) {
                expiryDate.setDate(startDay, (startMonth + 1) - 12, startYear + 1);
            }
            break;
        case 2:
            price = 11.0;
            period = "3 months";
            expiryDate.setDate(startDay, startMonth + 3, startYear);
            if (startMonth + 3 > 12) {
                expiryDate.setDate(startDay, (startMonth + 3) - 12, startYear + 1);
            }
            break;
        case 3:
            price = 45.0;
            period = "1 year";
            expiryDate.setDate(startDay, startMonth, startYear + 1);
            break;
        default:
            cout << "Invalid choice. Defaulting to 1 month plan.\n";
            price = 4.0;
            period = "1 month";
            expiryDate.setDate(startDay, startMonth + 1, startYear);
            if (startMonth + 1 > 12) {
                expiryDate.setDate(startDay, (startMonth + 1) - 12, startYear + 1);
            }
    }

    Member member(price, period, &startDate, &expiryDate);
    user.setMember(&member);
    user.setMemberStatus(true);

    cout << "Subscription complete!\n";
    member.displayMemberInfo();
    cout << endl;
}


#endif