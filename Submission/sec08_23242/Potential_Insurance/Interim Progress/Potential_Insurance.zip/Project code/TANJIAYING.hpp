#ifndef TANJIAYING_HPP
#define TANJIAYING_HPP


#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class Date {
protected:
    int day;
    int month;
    int year;
public:
    Date() : day(0), month(0), year(0) {}
    Date(int d, int m, int y) : day(d), month(m), year(y) {}

    string displayDayMonth(int d){
        if (d < 10)
                return "0"+ to_string(d); 
            else
                return to_string(d);
    }

    void setDate (int d, int m, int y){
        day = d;
        month = m;
        year = y;
    }

    void printDate() {
        cout << displayDayMonth(day) << "/" << displayDayMonth(month) << "/" << year << endl;
    }
};

class Rating {
protected:
    string feedback;
    int rating;
public:
    Rating() : feedback(""), rating(0) {}
    Rating(int r,string fb) : feedback(fb), rating(r) {}
    
    int getRating() {
        return rating;
    }
    string getFeedback(){
        return feedback;
    }
};

class Member {
protected:
    double price;
    string period;
    Date *startDate;
    Date *expiryDate;
    double const discountRate;
public:
    Member() : price(0.0), period(""), discountRate(0.06) {}
    Member(double p, string per, Date *sd, Date *ex)
        : price(p), period(per),startDate(sd),expiryDate(ex), discountRate(0.06)  {}

    double getdiscountRate(){
        return discountRate+1;
    }

    void displayExpiryDate() {
        expiryDate->printDate();
    }

    void displayMemberInfo() const {
        cout << "Price: " << price << endl;
        cout << "Period: " << period << endl;
        cout << "Start Date: "; startDate->printDate();
        cout << "Expiry Date: "; expiryDate->printDate();
        cout << "Discount Rate: " << discountRate*100 << "%" << endl;
    }
};

#define MAX_ITEMS 10

class Menu {
protected:
    string food[MAX_ITEMS],dessert[MAX_ITEMS],beverage[MAX_ITEMS];
    double foodPrice[MAX_ITEMS],dessertPrice[MAX_ITEMS],beveragePrice[MAX_ITEMS];
    int foodCount,dessertCount,beverageCount;
    Member *member;
public:
    Menu() : foodCount(0),dessertCount(0),beverageCount(0) {}

    void addFood(const string& item, double price) {
        if (foodCount < MAX_ITEMS) {
            food[foodCount] = item;
            foodPrice[foodCount] = price;
            foodCount++;
        }
    }

    void addDessert(const string& item, double price) {
        if (dessertCount < MAX_ITEMS) {
            dessert[dessertCount] = item;
            dessertPrice[dessertCount] = price;
            dessertCount++;
        }
    }

    void addBeverage(const string& item, double price) {
        if (beverageCount < MAX_ITEMS) {
            beverage[beverageCount] = item;
            beveragePrice[beverageCount] = price;
            beverageCount++;
        }
    }

    void displayFood(bool isMember) const {
        cout << "Food: ";
        for (int i = 0; i < foodCount; ++i) {
            cout << food[i] << " ";
            if (isMember) {
                cout << fixed << setprecision(2) << "(Member Price: RM" << foodPrice[i] * 0.94 << ") \n";
            } else {
                cout << fixed << setprecision(2) << "(Price: RM" << foodPrice[i] << ") \n";
            }
        }
        cout << endl;
    }

    void displaydessert(bool isMember) const {
        cout << "Dessert: ";
        for (int i = 0; i < dessertCount; ++i) {
            cout << dessert[i] << " ";
            if (isMember) {
                cout << fixed << setprecision(2) << "(Member Price: RM" << dessertPrice[i] * 0.94 << ") \n";
            } else {
                cout << fixed << setprecision(2) << "(Price: RM" << dessertPrice[i] << ") \n";
            }
        }
        cout << endl;
    }

    void displaybeverage(bool isMember) const {
        cout << "Beverage: ";
        for (int i = 0; i < beverageCount; ++i) {
            cout << beverage[i] << " ";
            if (isMember) {
                cout << fixed << setprecision(2) << "(Member Price: RM" << beveragePrice[i] * 0.94 << ") \n";
            } else {
                cout << fixed << setprecision(2) << "(Price: RM" << beveragePrice[i] << ") \n";
            }
        }
        cout << endl;
    }
};

#endif