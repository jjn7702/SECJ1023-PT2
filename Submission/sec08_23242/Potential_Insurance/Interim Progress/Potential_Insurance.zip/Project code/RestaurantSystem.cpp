#include "TANJIAYING.hpp"
#include "ANGIE.hpp"
#include "TANZHENGYU.hpp"
#include "TANZHENGYU.cpp"
#include <iostream>
#include <iomanip>

const int MAX_RESTAURANTS = 10;

int main(){
    UserManager userManager;

    User users[10];
    int userCount = 0;
    int restaurantCount = 0;

    bool continueProgram = true;
    int option;

    Menu menu1;
    menu1.addFood("Burger", 5.0);
    menu1.addFood("Pizza", 8.0);
    menu1.addBeverage("CEO Coffee", 10.0);
    menu1.addDessert("Lava cake", 15);

    Address address1("123", "Road", userManager.getCity(0));
    Address address2("456", "Avenue", userManager.getCity(1));
    Address address3("789", "Jalan Amal", userManager.getCity(2));

    //defining restaurant information
    RestaurantLists System;

    //ABC Restaurant
    Restaurant* ABC_Restaurant = new Western("ABC Restaurant", &address1, &menu1);
    Rating rating1(5,"The food is really amazing!!");
    ABC_Restaurant->addRating(&rating1);
    System.addRestaurant(ABC_Restaurant);

    //Zuss Coffee
    Restaurant* Zuss_Coffee = new Cafe("Zuss Coffee", &address2, &menu1);
    Rating rating2(4,"I love their drink!!");
    Rating rating3(5,"Their CEO Coffee is quite nice.");
    Zuss_Coffee->addRating(&rating2);
    Zuss_Coffee->addRating(&rating3);
    System.addRestaurant(Zuss_Coffee);

    //Marryblue
    Restaurant* Marryblue = new Fastfood("Marryblue", &address3, &menu1);
    System.addRestaurant(Marryblue);



    User currentUser;
    char isNewUser;
    cout << "================================================================\n";
    cout << "=============== Restaurant Recommendation System ===============\n";
    cout << "================================================================\n";
    cout << endl;
    cout << "        Welcome to our restaurant recommendation system         \n\n";

    while (continueProgram) {
        cout << "Are you a new user? (y/n): ";
        cin >> isNewUser;

        if (isNewUser == 'y' || isNewUser == 'Y') {
            signUp(users, userCount, userManager);
        } else {
            User currentUser;
            bool loggedIn = login(users, userCount, currentUser);
            if (!loggedIn) {
                cout << "Invalid username or password. Please try again.\n";
                continue;
            }

            // Set a flag indicating the user is authenticated
            bool isAuthenticated = true;

            int option;
            while (isAuthenticated) {
                cout << "Menu option\n";
                cout << "1) User information\n";
                cout << "2) Member subscription\n";
                cout << "3) Restaurant option\n";
                cout << "4) Logout\n";
                cout << "Please select the option: ";
                cin >> option;

                switch (option) {
                    case 1:
                        currentUser.displayUserInfo();
                        cout << "Do you want to change your information? (y/n): ";
                        char changeInfo;
                        cin >> changeInfo;
                        if (changeInfo == 'y' || changeInfo == 'Y') {
                            updateUserInfo(currentUser, users, userCount, userManager.cities);
                        }
                        break;
                    case 2:
                        memberSubscription(currentUser);
                        break;
                    case 3:
                        int restaurantOption;
                        cout << "Restaurant option\n";
                        cout << "----------------------------------------------------------------\n";
                        cout << "1) Search restaurant by restaurant name\n";
                        cout << "2) Recommended restaurant nearby the user\n";
                        cout << "3) Search restaurant by restaurant type\n";
                        cout << "Choose your option: ";
                        cin >> restaurantOption;

                        if (restaurantOption == 1){
                            cout << "Search or type the name of restaurant:";
                            string a;
                            cin >> a;
                            System.FindRestaurantbyName(a);
                            System.displayRestaurant(currentUser.getIsMember());
                            }
                        else if (restaurantOption == 2){
                            System.FindRestaurantNearby(&currentUser);
                            System.displayRestaurant(currentUser.getIsMember());
                            }
                        else if (restaurantOption == 3){
                            cout << "Here is the type of restaurant\n";
                            cout << "----------------------------------------------------------------\n";
                            cout << "W - Western Restaurant\n";
                            cout << "C - Cafe\n";
                            cout << "F - Fastfood Restaurant\n";
                            cout << "Please choose the type of restaurant interested: ";
                            char restaurantTypeChoice;
                            cin >> restaurantTypeChoice;
                            System.FindRestaurantType(restaurantTypeChoice);
                            System.displayRestaurant(currentUser.getIsMember());
                            }
                        break;
                    case 4:
                        // Logout the user and exit the loop
                        isAuthenticated = false;
                        continueProgram = false;
                        break;
                    default:
                        cout << "Invalid option.\n";
                        break;
                }

                if (!isAuthenticated) {
                    break;
                }

                cout << "Continue to other option? (y/n): ";
                char cont;
                cin >> cont;
                if (cont == 'n' || cont == 'N') {
                    continueProgram = false;
                    break;
                }
            }
        }

        if (!continueProgram) {
            break;
        }
    }

    cout << "Thank you for using our system!!\n";



    system("pause");
    return 0;
}