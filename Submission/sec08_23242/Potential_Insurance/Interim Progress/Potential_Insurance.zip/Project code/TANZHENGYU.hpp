#ifndef TANZHENGYU_HPP
#define TANZHENGYU_HPP

#include "ANGIE.hpp"
#include "TANJIAYING.hpp"
#include <iostream>
using namespace std;

#define N 10

class Restaurant {
    protected:
        string Name;
        Address* address; // shows aggregation
        Menu * menu;
        Rating * ratingList[N];
        int AvgRating;
        int numR;
    
    public:
        Restaurant();
        Restaurant(string n, Address *a, Menu *m);
        ~Restaurant();
        string getName();
        string getCity();
        virtual void displayMenu(bool isMember); //Shows polymerism
        void addRating(Rating *R);
        double calculateAvg(); // Return average rating
        void displayRating();
        void inputRating();
};

class Western : public Restaurant {
    public:
        Western(string n, Address *a, Menu *m): Restaurant(n,a,m){};
        void displayMenu(bool isMember);
};

class Cafe : public Restaurant {
    public:
        Cafe(string n, Address *a, Menu *m): Restaurant(n,a,m){};
        void displayMenu(bool isMember);
};

class Fastfood : public Restaurant {
    public:
        Fastfood(string n, Address *a, Menu *m): Restaurant(n,a,m){};
        void displayMenu(bool isMember);
};

class RestaurantLists {
    protected:
        Restaurant *RestaurantList[N]; //show aggregations
        User *user1; //show aggregation
        int numP,numC,choice; //number of restaurant and number of choice
        int Restaurantchoice[N]; //show the Restaurant is at which choice

    public:
        RestaurantLists();
        void addRestaurant(Restaurant *r);
        void FindRestaurantbyName(string a);
        void FindRestaurantNearby(User *u);
        void FindRestaurantType(char a);
        void displayRestaurant(bool isMember);
};

#endif
