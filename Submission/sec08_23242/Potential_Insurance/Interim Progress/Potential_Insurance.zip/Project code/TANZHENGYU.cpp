#include "TANZHENGYU.hpp"
#include "TANJIAYING.hpp"
#include "ANGIE.hpp"

#include <iostream>
using namespace std;

//Class Restaurant
Restaurant::Restaurant(){
    Name = "";
    numR = 0;
    AvgRating = 0;
}

Restaurant::Restaurant(string n, Address *a, Menu *m){
    Name = n;
    address = a;
    menu = m;
    numR = 0;
    AvgRating = 0;
}

string Restaurant::getName(){
    return Name;
}

string Restaurant::getCity(){
    return address->getcity();
}

void Restaurant::displayMenu(bool isMember) {
    cout << "Here is the menu of Restaurant" << endl;
    cout << "----------------------------------------------------------------\n";
}

void Restaurant::addRating(Rating *R){
    ratingList[numR] = R;
    numR++;
}

double Restaurant::calculateAvg(){
    double total = 0;
    for (int i = 0; i < numR; i++){
        total += ratingList[i]->getRating();
    }
    double Avg = total/numR;
    return Avg;
}

void Restaurant::displayRating(){
    cout << "This is the rating of this restaurant: \n";
    cout << "----------------------------------------------------------------\n";
    cout << "The average rating for this restaurant is " << calculateAvg();
    cout << endl;
    for (int i = 0; i < numR; i++){
        cout << "Rating" << i+1 << ": " << ratingList[i]->getRating() << endl;
        cout << "Feedback" << i+1 << ": " << ratingList[i]->getFeedback() << endl << endl;
    }
}

void Restaurant::inputRating(){
    int r;
    string f;
    cout << "Please input your rating (1-5): ";
    cin >> r;
    cout << "Please input your feedback: \n";
    cin.ignore();
    getline(cin,f);
    cout << "Thank you for your feedback!!!\n";
    cout << "Your feedback will show in next refresh.\n";
    Rating* newRating = new Rating(r, f); // Dynamically allocate new Rating
    ratingList[numR++] = newRating; // Store the new Rating pointer in the array
}

//class western
void Western::displayMenu(bool isMember){
    Restaurant::displayMenu(isMember);
    menu->displayFood(isMember);
    menu->displaybeverage(isMember);
}

//class cafe
void Cafe::displayMenu(bool isMember){
    Restaurant::displayMenu(isMember);
    menu->displaydessert(isMember);
    menu->displaybeverage(isMember);
}

//class fastfood
void Fastfood::displayMenu(bool isMember){
    Restaurant::displayMenu(isMember);
    menu->displayFood(isMember);
    menu->displaybeverage(isMember);
}

//class RestaurantLists
RestaurantLists::RestaurantLists(){
    numP = 0;
    numC = 0;
    choice = 0;
}

void RestaurantLists::addRestaurant(Restaurant *r){
    RestaurantList[numP] = r;
    numP++;
}

void RestaurantLists::FindRestaurantbyName(string a){
    cout << "Here is the restaurant found based on ur input: \n";
    cout << "----------------------------------------------------------------\n";

    for (int i=0;i < numP; i++){
        if (RestaurantList[i]->getName().find(a) != string::npos){
            cout << numC+1 << "- " << RestaurantList[i]->getName() << endl;
            Restaurantchoice[numC] = i;
            numC++;
        }
    } 
    numC = 0; //reset numC
}

void RestaurantLists::FindRestaurantNearby(User *u){
    cout << "Here is the restaurant found nearby: \n";
    cout << "----------------------------------------------------------------\n";
    user1 = u;
    for (int i=0;i < numP; i++){
        if (RestaurantList[i]->getCity() == user1->getCity()){
            cout << numC+1 << "- " << RestaurantList[i]->getName() << endl;
            Restaurantchoice[numC] = i;
            numC++;
        }
    } 
    numC = 0; //reset numC
}

void RestaurantLists::FindRestaurantType(char a){
    switch(a)
    {
        case 'W':
        case 'w':
            cout << "Here is the western restaurant: \n";
            cout << "----------------------------------------------------------------\n";
            for (int i=0;i < numP; i++){
                if (dynamic_cast<Western*>(RestaurantList[i])){
                    cout << numC+1 << "- " << RestaurantList[i]->getName() << endl;
                    Restaurantchoice[numC] = i;
                    numC++;
                }
            }
            numC = 0; //reset numC
            break;
        case 'C':
        case 'c':
            cout << "Here is the cafe: \n";
            cout << "----------------------------------------------------------------\n";
            for (int i=0;i < numP; i++){
                if (dynamic_cast<Cafe*>(RestaurantList[i])){
                    cout << numC+1 << "- " << RestaurantList[i]->getName() << endl;
                    Restaurantchoice[numC] = i;
                    numC++;
                }
            }
            numC = 0; //reset numC
            break;
        case 'F':
        case 'f':
            cout << "Here is the fastfood restaurant: \n";
            cout << "----------------------------------------------------------------\n";
            for (int i=0;i < numP; i++){
                if (dynamic_cast<Fastfood*>(RestaurantList[i])){
                    cout << numC+1 << "- " << RestaurantList[i]->getName() << endl;
                    Restaurantchoice[numC] = i;
                    numC++;
                }
            }
            numC = 0; //reset numC
            break;
        default:
            cout << "The input is invalid\n";
    } 
}

void RestaurantLists::displayRestaurant(bool a){
    cout << "Choose ur preferred restaurant(number): ";
    cin >> choice;
    
    cout << "Restaurant name: " << RestaurantList[Restaurantchoice[choice-1]]->getName() << endl;
    cout << "Restaurant city: " << RestaurantList[Restaurantchoice[choice-1]]->getCity() << endl << endl;
    RestaurantList[Restaurantchoice[choice-1]]->displayMenu(a);
    RestaurantList[Restaurantchoice[choice-1]]->displayRating();
    char Ratingchoice;
    cout << "Do you want to give a rating & feedback? [y/n]";
    cin >> Ratingchoice;
    if (Ratingchoice == 'y' || Ratingchoice == 'Y'){
        RestaurantList[Restaurantchoice[choice-1]]->inputRating();
    }
}

