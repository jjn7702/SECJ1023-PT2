#ifndef ALLERGY_H
#define ALLERGYH

#include <iostream>
#include <array>
#include <string>
#include <limits>
#include <fstream>
const int MAX_INGREDIENT=10;
using namespace std;

class Ingredient{
    string ingredient[MAX_INGREDIENT];
    int count;
    public:
        Ingredient(string _ingredient[] = nullptr, int _count = 0) {
            count = _count;
            if (_ingredient != nullptr) {
                for (int i = 0; i < count; ++i) {
                    ingredient[i] = _ingredient[i];
                }
            } else {
                for (int i = 0; i < count; ++i) {
                    ingredient[i] = "";
                }
            }
        }
        void setCount(int c){
            count = c;
        }
        int getCount(){
            return count;
        }
        void inputIngredient(int _count){
            for(int i=count;i<_count + count ;i++){
                cout << endl << setw(15) << "" << "Enter ingredient :";
                getline(cin, ingredient[i]);
            }
        }

        void removeIngredient(int _count){
            _count = _count - 1;
            for (int i=_count; i<count-1; i++){
                ingredient[i] = ingredient[i+1];
            }
        }

        string *getIngredients(){
            return ingredient;
        }
};

class User {
protected:
    string name;

public:
    User(string n = "") : name(n) {}

    void inputName() {
        cout << "Name: ";
        cin.ignore();
        getline(cin,name);

    }

    string getName(){
        return name;
    }

    virtual void inputDetails() = 0;
    virtual string returnGender() = 0;
    virtual int returnAge() = 0;
    virtual ~User()=default;
};

class Male : public User {
    int age;
    string gender;

public:
    Male() : User() {}

    void inputAge() {
        do {
        cout << "Age: ";
        cin >> age;

        if (cin.fail()) {
            cout << "Please enter a valid number!" << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        else if (age < 0) {
            cout << "Invalid age. Please enter a non-negative value." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        else {
            break;
        }

    } while (true);
    }

    void inputDetails() {
        inputName();
        inputAge();
        gender = "Male";
    }

    string returnGender(){
        return gender;
    }

    int returnAge(){
        return age;
    }
};

class Female : public User {
    int age;
    string gender;

public:
    Female() : User() {}

    void inputAge() {
        do {
        cout << "Age: ";
        cin >> age;

        if (cin.fail()) {
            cout << "Please enter a valid number!" << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        else if (age < 0) {
            cout << "Invalid age. Please enter a non-negative value." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        else {
            break;
        }

    } while (true);
    }

    void inputDetails() {
        inputName();
        inputAge();
        gender = "Female";
    }

    string returnGender(){
        return gender;
    }

    int returnAge(){
        return age;
    }
};

class Allergy{
    private:
        string Found[50];
        Ingredient *ingredient;
        string *ingredients;
        int ingredientCount;
        int count;

    public:
        void statusAllergy(Ingredient* obj) {
        count = 0;
        ingredient = obj;
        ingredientCount = obj->getCount();
        ingredients = obj->getIngredients();

        


        ifstream infile; 
        
        infile.open("Allergy List.txt");
        int lines = 0;
        string line;

        while(getline(infile,line))
            lines++;
        
        string Allergies[lines];

        infile.clear();
        infile.seekg(0);

        for (int i= 0; i<lines; i++)
            getline(infile,Allergies[i]);

        infile.close();

        for (int i = 0; i < ingredientCount; i++) {
            for (int j = 0; j < lines; j++) {
                bool insert = true;
                string currentIngredient = ingredients[i];
                string currentAllergy = Allergies[j];

                for(int z=0; z < ingredients[i].size(); z++){
                        currentIngredient[z] = tolower(currentIngredient[z]);
                    }

                for(int z=0; z < Allergies[i].size(); z++){
                    currentAllergy[z] = tolower(currentAllergy[z]);
                }

                if (currentIngredient == currentAllergy || currentIngredient.find(currentAllergy) != string::npos) {
                    for (int p = 0; p < count; p++) {
                        if (Found[p] == Allergies[j])
                            insert = false;
                    }
                    if (insert && count < lines) {
                        Found[count] = Allergies[j];
                        count++;
                    }
                }
            }
        }
    }
        string *GetFound(){
            return Found;
        }
        int getCounts(){
            return count;
        }

        

};

class Alert{
        Allergy *alergik;
    public:
        void notificationAlert(Allergy *a){
        alergik = a;
        int count = alergik->getCounts();
        string* foundAllergies = alergik->GetFound();

        if(count > 0){
            cout << setw(15) << "" << "Alert! There is an allergic ingredient in the food. List updated. "<< endl << endl;
         }
        }


};

#endif