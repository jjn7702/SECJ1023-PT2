//MUHAMMAD THAQIF AMMAR BIN MUHAMMED SUFIAN (A23CS0251)
//MUHAMMAD ANIQ AZIQ BIN AZME (A23CS0122)
//AHMAD RAZIQ BIN AHMAD RAIF (A23CS0037)
//GROUP 3

#include <iostream>
#include <array>
#include <string>
#include <iomanip>
#include <limits>

#include "Allergy.h"
using namespace std;

void Ingredients(Ingredient &menu, User *user);
void Allergies(Ingredient &menu, User *user);
void displayMenu(Ingredient &menu , User *user);
void Information(Ingredient &menu, User *user);
void AboutUs(Ingredient &menu, User *user);

void displayMenu(Ingredient &menu, User *user){
    system("cls");
    int opt = 0;

    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(39) << "FOOD ALLERGY SYSTEM" << setw(27) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(40) << "Choose Your Option: " << setw(26) << "|" << endl;
    cout << setw(15) << "" << "+---------------+-----------+---------------+------------+--------+" << endl;
    cout << setw(16) << "|" << setw(11) << " 1.Ingredients " << setw(12) << "| 2.Allergy " << setw(13) << "| 3.Information " << setw(9) << "| 4.About Us " << setw(6) << "| 5.Exit |" << endl;
    cout << setw(15) << "" << "+---------------+-----------+---------------+------------+--------+" << endl;

    do {
        cout << endl << setw(15) << "" << "My option => ";
        cin >> opt;

        if (cin.fail()) {
            cout << setw(15) << "" << "Please enter a valid number!" << endl;
            cin.clear(); 
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else if(opt < 1 || opt > 5){
            cout << setw(15) << "" << "Please enter a valid option!" << endl;
        } else {
            break;
        }
    } while (true);

    switch(opt){
        case 1: Ingredients(menu, user);
                break;
        case 2: Allergies(menu, user);
                break;
        case 3: Information(menu, user);
                break;
        case 4: AboutUs(menu, user);
                break;
        default: break;
    }
}

void Ingredients(Ingredient &menu , User *user){
    system("cls");
    int count;
    int opt = 0;

    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(39) << "INGREDIENTS" << setw(27) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    if (menu.getCount() <= 0)
        cout << setw(16) << "|" << setw(45) << "You have no ingredients" << setw(21) << "|" << endl;
    else {
        string *ingredientArray;
        ingredientArray = menu.getIngredients();
        for (int i=0; i<menu.getCount(); i++){
            int paddingstart = 29;
            int paddingend = 35 - ingredientArray[i].size();
            cout << setw(16) << "|" << setw(paddingstart) << i+1 << ". " << ingredientArray[i] << setw(paddingend) << "|" << endl;
        }
    }
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(42) << "Choose Your Option: " << setw(24) << "|" << endl;
    cout << setw(15) << "" << "+------------------------+--------------------------+-------------+" << endl;
    cout << setw(16) << "|" << setw(16) << "   1. Add Ingredients   " << setw(12) << "|   2. Remove Ingredient   " << setw(6) << "|   3. Exit   |" << endl;
    cout << setw(15) << "" << "+------------------------+--------------------------+-------------+" << endl;

    do {
        cout << endl << setw(15) << "" << "My option => ";
        cin >> opt;

        if (cin.fail()) {
            cout << setw(15) << "" << "Please enter a valid number!" << endl;
            cin.clear(); 
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else if(opt < 1 || opt > 3){
            cout << setw(15) << "" << "Please enter a valid option!" << endl;
        } else {
            break;
        }
    } while (true);
    
    switch(opt){
        case 1: do{
                    cout << setw(15) << "" <<"How many the ingredient in one dishes: ";
                    cin>>count;
                    cin.ignore();
                    if(cin.fail()){
                        cout << endl << setw(15) << "" << "Please enter a valid number!" << endl;
                        cin.clear(); 
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    } else if(count < 0){
                        cout << endl << setw(15) << "" << "Please enter a non-zero number!" << endl;
                    }
                    else if((menu.getCount() + count)>MAX_INGREDIENT){
                        cout << endl << setw(15) << "" << "Reenter again(ingredient maximum 10)" << endl;
                    } else{
                        menu.inputIngredient(count);
                        menu.setCount(menu.getCount() + count);
                        break;
                    }
                }while(true);
                Ingredients(menu, user);
                break;
        case 2: do{
                    cout << endl << setw(15) << "" << "Which ingredient would you like to remove: ";
                    cin >> count;
                    if(cin.fail()){
                        cout << endl << setw(15) << "" << "Please enter a valid number!" << endl;
                        cin.clear(); 
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    } else if(menu.getCount() < count){
                        cout << endl << setw(15) << "" << "The ingredient that you would like to remove doesn't exist!" << endl << endl;
                        system("pause");
                        break;
                    } else if(count < 0) {
                        cout << endl << setw(15) << "" << "Please enter a non-zero number!" << endl;
                    } else {
                        menu.removeIngredient(count);
                        menu.setCount(menu.getCount() - 1);
                        break;
                    }
                } while (true);
                Ingredients(menu, user);
                break;
        case 3: displayMenu(menu, user);
                break;
    }
}

void Allergies(Ingredient &menu, User *user){
    system("cls");
    int opt = 0;

    Allergy allergy;

    allergy.statusAllergy(&menu);

    Alert Alert;
    Alert.notificationAlert(&allergy);
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(39) << "YOUR ALLERGIES" << setw(27) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    if (allergy.getCounts() <= 0)
        cout << setw(16) << "|" << setw(41) << "You have no allergy" << setw(25) << "|" << endl;
    else {
        string *FoundAllergy;
        FoundAllergy = allergy.GetFound();
        for (int i=0; i<allergy.getCounts(); i++){
            int paddingstart = 29;
            int paddingend = 35 - FoundAllergy[i].size();
            cout << setw(16) << "|" << setw(paddingstart) << i+1 << ". " << FoundAllergy[i] << setw(paddingend) << "|" << endl;
        }
    }
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(42) << "Choose Your Option: " << setw(24) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(35) << "1. Exit" << setw(31) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;

    do {
        cout << endl << setw(15) << "" << "My option => ";
        cin >> opt;

        if (cin.fail()) {
            cout << setw(15) << "" << "Please enter a valid number!" << endl;
            cin.clear(); 
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else if(opt != 1){
            cout << setw(15) << "" << "Please enter a valid option!" << endl;
        } else {
            break;
        }
    } while (true);

    switch(opt){
        case 1: displayMenu(menu,user);
                break;
    }
}

void Information(Ingredient &menu, User *user){

    system("cls");
    
    int opt = 0;
    string *ingredientArray = menu.getIngredients();
    Allergy allergy;

    allergy.statusAllergy(&menu);
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(41) << "PERSONAL INFORMATION" << setw(25) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(5) << "" << "Name: " << user->getName() << setw(55 - user->getName().size()) << "|" << endl;
    cout << setw(16) << "|" << setw(5) << "" << "Age: " << user->returnAge() << setw(56 - to_string(user->returnAge()).size()) << "|" << endl;
    cout << setw(16) << "|" << setw(5) << "" << "Gender: " << user->returnGender() << setw(53 - user->returnGender().size()) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    if(menu.getCount()!= 0){
        allergy.statusAllergy(&menu);
        cout << setw(16) << "|" << setw(36) << "INGREDIENTS" << setw(30) << "|" << endl;
        cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
        for(int i=0; i<menu.getCount(); i++){
            cout << setw(16) << "|" << setw(6) << i+1 << ". " << ingredientArray[i] << setw(58 - ingredientArray[i].size()) << "|" << endl;
        }
        cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    } 

    if(allergy.getCounts() != 0){
        string *allergyArray = allergy.GetFound();
        cout << setw(16) << "|" << setw(35) << "ALLERGIES" << setw(31) << "|" << endl;
        cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
        for(int i=0; i<allergy.getCounts(); i++){
            cout << setw(16) << "|" << setw(6) << i+1 << ". " << allergyArray[i] << setw(58 - allergyArray[i].size()) << "|" << endl;
        }
        cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    }

    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(42) << "Choose Your Option: " << setw(24) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(35) << "1. Exit" << setw(31) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;

    do {
        cout << endl << setw(15) << "" << "My option => ";
        cin >> opt;

        if (cin.fail()) {
            cout << setw(15) << "" << "Please enter a valid number!" << endl;
            cin.clear(); 
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else if(opt != 1){
            cout << setw(15) << "" << "Please enter a valid option!" << endl;
        } else {
            break;
        }
    } while (true);

    switch(opt){
        case 1: displayMenu(menu,user);
                break;
    }
}
                                            
void AboutUs(Ingredient &menu, User *user){
    int opt = 0;
    system("cls");
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(35) << "ABOUT US" << setw(31) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << "Special thanks to: " << setw(47) << "|" << endl;
    cout << setw(16) << "|" << setw(66) << "|" << endl;
    cout << setw(16) << "|" << "1. Ahmad Raziq bin Ahmad Raif (A23CS0037)" << setw(25) << "|" << endl;
    cout << setw(16) << "|" << "2. Muhammad Aniq Aziq bin Azme (A23CS0122)" << setw(24) << "|" << endl;
    cout << setw(16) << "|" << "3. Muhammad Thaqif Ammar bin Muhammed Sufian (A23CS0251)" << setw(10) << "|" << endl;
    cout << setw(16) << "|" << setw(66) << "|" << endl;
    cout << setw(16) << "|" << "We would like to express our gratitude to Raziq, Aniq, and Thaqif|" << endl;
    cout << setw(16) << "|" << "for developing this system. Your hard work, dedication, and" << setw(7) << "|" << endl;
    cout << setw(16) << "|" << "expertise have created a solution that addresses a critical " << setw(6) << "|" << endl;
    cout << setw(16) << "|" << "health issue with innovation and precision. The impact of your " << setw(3) << "|" << endl;
    cout << setw(16) << "|" << "efforts will undoubtedly improve the lives of many, and we" << setw(8) << "|" << endl;
    cout << setw(16) << "|" << "and we deeply appreciate the commitment and collaborative spirit" << setw(2) << "|" << endl;
    cout << setw(16) << "|" << "you demonstrated throughout this project. Thank you for your" << setw(6) << "|" << endl;
    cout << setw(16) << "|" << "invaluable contribution to our community and beyond ^.^" << setw(11) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(42) << "Choose Your Option: " << setw(24) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;
    cout << setw(16) << "|" << setw(35) << "1. Exit" << setw(31) << "|" << endl;
    cout << setw(15) << "" << "+-----------------------------------------------------------------+" << endl;

    do {
        cout << endl << setw(15) << "" << "My option => ";
        cin >> opt;

        if (cin.fail()) {
            cout << setw(15) << "" << "Please enter a valid number!" << endl;
            cin.clear(); 
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else if(opt != 1){
            cout << setw(15) << "" << "Please enter a valid option!" << endl;
        } else {
            break;
        }
    } while (true);

    switch(opt){
        case 1: displayMenu(menu,user);
                break;
    }
}

int main() {
    string gender;
    User* user = nullptr;
    int opt = 0;

    do {
        cout << "Enter gender (Male/Female): ";

        try{
            cin >> gender;

            for(int z=0; z < gender.size(); z++)
                    gender[z] = tolower(gender[z]);
            
            if((gender == "male") || (gender == "m"))
                user = new Male();
            else if((gender == "female") || (gender == "f"))
                user = new Female();
            else
                throw(gender);
        }
        
        catch(string invalid){
            cout << "Invalid gender!" << endl << endl;
        }
    } while ((gender != "male") && (gender != "female") && (gender != "f") && (gender != "m"));

    if (user) {
        user->inputDetails(); 
    }
    Ingredient menu;


    displayMenu(menu , user);

    delete user;

    system("pause");
    return 0;
}
