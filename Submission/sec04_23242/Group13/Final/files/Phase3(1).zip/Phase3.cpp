#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <regex>

using namespace std;

int loginpage();
void clearScreen();

// Fouad's class 1
class Person {
protected:
    string name;
    string gender;

public:
    Person(const string& name, const string& gender) : name(name), gender(gender) {}

    string getName() const {
        return name;
    }

    string getGender() const {
        return gender;
    }
};

// Moqbel's class 1
class User : public Person {
private:
    string email;
    string password;
    vector<string> genres;
    vector<string> actors;
    vector<string> directors;
    vector<pair<int, int>> ratings; // Pair of movieID and rating
    vector<int> watchlist;

public:
    User(const string& uname, const string& ugender, const string& uemail, const string& upassword)
        : Person(name, gender), email(uemail), password(upassword) {}

    string getEmail() const {
        return email;
    }

    string getPassword() const {
        return password;
    }

    void setGenres(const vector<string>& genres) {
        this->genres = genres;
    }

    void setActors(const vector<string>& actors) {
        this->actors = actors;
    }

    void setDirectors(const vector<string>& directors) {
        this->directors = directors;
    }

    void rateMovie(int movieID, int rating) {
        for (size_t i = 0; i < ratings.size(); ++i) {
            if (ratings[i].first == movieID) {
                ratings[i].second = rating;
                return;
            }
        }
        ratings.push_back(make_pair(movieID, rating));
    }

    int getRating(int movieID) const {
        for (size_t i = 0; i < ratings.size(); ++i) {
            if (ratings[i].first == movieID) {
                return ratings[i].second;
            }
        }
        return -1; // Movie not rated
    }

    void updatePreferences(const vector<string>& newGenres, const vector<string>& newActors, const vector<string>& newDirectors) {
    setGenres(newGenres);
    setActors(newActors);
    setDirectors(newDirectors);
    }

    const vector<string>& getGenres() const {
        return genres;
    }

    const vector<string>& getActors() const {
        return actors;
    }

    const vector<string>& getDirectors() const {
        return directors;
    }

     void addToWatchlist(int movieID) {
        watchlist.push_back(movieID);
        cout << "Movie added to watchlist!" << endl;
    }

    const vector<int>& getWatchlist() const {
        return watchlist;
    }
};

int menu(User*);

// Moqbel's class 2
class Movie {
private:
    int movieID;
    string title;
    vector<string> genres;
    string director;
    vector<string> cast;
    string releaseDate;
    vector<pair<int, int>> ratings; // Pair of userID and rating

public:
    Movie(int tmovieID, const string& ttitle, const vector<string>& tgenres, const string& tdirector, const vector<string>& tcast, const string& treleaseDate)
        : movieID(tmovieID), title(ttitle), genres(tgenres), director(tdirector), cast(tcast), releaseDate(treleaseDate) {}

    int getMovieID() const {
        return movieID;
    }

    string getTitle() const {
        return title;
    }

    const vector<string>& getGenres() const {
        return genres;
    }

    string getDirector() const {
        return director;
    }

    const vector<string>& getCast() const {
        return cast;
    }

    string getReleaseDate() const {
        return releaseDate;
    }

    void addRating(int userID, int rating) {
        for (size_t i = 0; i < ratings.size(); ++i) {
            if (ratings[i].first == userID) {
                ratings[i].second = rating;
                return;
            }
        }
        ratings.push_back(make_pair(userID, rating));
    }

    double getAverageRating() const {
        if (ratings.empty()) {
            return 0.0;
        }
        double totalRating = 0.0;
        for (size_t i = 0; i < ratings.size(); ++i) {
            totalRating += ratings[i].second;
        }
        return totalRating / ratings.size();
    }
};

// Fouad's class 2
class Genre {
private:
    int genreID;
    string type;
    vector<Movie*> movies;

public:
    Genre(int tgenreID, const string& ttype) : genreID(tgenreID), type(ttype) {}

    int getGenreID() const {
        return genreID;
    }

    string getType() const {
        return type;
    }

    void addMovie(Movie* movie) {
        movies.push_back(movie);
    }

    const vector<Movie*>& getMovies() const {
        return movies;
    }
};

// Ali's class 1
class Director : public Person {
private:
    int directorID;
    vector<Movie*> movies;

public:
    Director(const string& name, const string& gender, int ddirectorID)
        : Person(name, gender), directorID(ddirectorID) {}

    int getDirectorID() const {
        return directorID;
    }

    void addMovie(Movie* movie) {
        movies.push_back(movie);
    }

    const vector<Movie*>& getMovies() const {
        return movies;
    }
};

// Kinan's class 1
class Actor : public Person {
private:
    int actorID;
    vector<Movie*> movies;

public:
    Actor(const string& name, const string& gender, int aactorID)
        : Person(name, gender), actorID(aactorID) {}

    int getActorID() const {
        return actorID;
    }

    void addMovie(Movie* movie) {
        movies.push_back(movie);
    }

    const vector<Movie*>& getMovies() const {
        return movies;
    }
};

// Kinan's class 2
class RecommendationSystem {
private:
    vector<User*> users;
    vector<Movie*> movies;
    vector<Genre*> genres;
    vector<Director*> directors;
    vector<Actor*> actors;
    string recommendationAlgorithm = "Content-Based Filtering";

public:
    void addUser(User* user) {
        users.push_back(user);
    }

    void addMovie(Movie* movie) {
        string newGenre;
        movies.push_back(movie);
        for (const auto& genre : movie->getGenres()) {
            bool genreFound = false;
            for (auto& g : genres) {
                if (g->getType() == genre) {
                    g->addMovie(movie);
                    genreFound = true;
                    break;
                }
            }
            if (!genreFound) {
                Genre* newGenre = new Genre(genres.size() + 1, genre);
                newGenre->addMovie(movie);
                genres.push_back(newGenre);
            }
        }

        for (auto& director : directors) {
            if (director->getName() == movie->getDirector()) {
                director->addMovie(movie);
                break;
            }
        }

        for (const auto& actorName : movie->getCast()) {
            for (auto& actor : actors) {
                if (actor->getName() == actorName) {
                    actor->addMovie(movie);
                    break;
                }
            }
        }
    }

    // Generate movie recommendations based on user preferences
    vector<Movie*> generateRecommendations(const User& user) {
        vector<Movie*> recommendations;
        const auto& userGenres = user.getGenres();
        const auto& userActors = user.getActors();
        const auto& userDirectors = user.getDirectors();

        for (const auto& movie : movies) {
            // Check if the movie matches user's favorite genres
            bool matchesGenre = any_of(movie->getGenres().begin(), movie->getGenres().end(),
                [&userGenres](const string& genre) {
                    return find(userGenres.begin(), userGenres.end(), genre) != userGenres.end();
                });

            // Check if the movie matches user's favorite actors
            bool matchesActor = any_of(movie->getCast().begin(), movie->getCast().end(),
                [&userActors](const string& actor) {
                    return find(userActors.begin(), userActors.end(), actor) != userActors.end();
                });

            // Check if the movie matches user's favorite directors
            bool matchesDirector = find(userDirectors.begin(), userDirectors.end(), movie->getDirector()) != userDirectors.end();

            // Add the movie to recommendations if it matches any preference
            if (matchesGenre || matchesActor || matchesDirector) {
                recommendations.push_back(movie);
            }
        }

        return recommendations;
    }

    // Update the recommendation algorithm (if needed)
    void updateAlgorithm(const string& algorithm) {
        recommendationAlgorithm = algorithm;
    }

    // Load users from a file
    void loadUsers(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cerr << "Unable to open file: " << filename << endl;
            return;
        }

        string name, gender, email, password;
        while (file >> name >> gender >> email >> password) {
            User* user = new User(name, gender, email, password);
            users.push_back(user);
        }

        file.close();
    }

    // Save users to a file
    void saveUsers(const string& filename) {
        ofstream file(filename);
        if (!file.is_open()) {
            cerr << "Unable to open file: " << filename << endl;
            return;
        }

        for (const auto& user : users) {
            file << user->getName() << " "
                << user->getGender() << " "
                << user->getEmail() << " "
                << user->getPassword() << endl;
        }

        file.close();
    }

    // Load movies from a file
    void loadMovies(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cerr << "Unable to open file: " << filename << endl;
            return;
        }

        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            int movieID;
            string title, director, releaseDate;
            vector<string> genres, cast;
            string genre, actor;
            
            ss >> movieID >> title >> director >> releaseDate;
            while (ss >> genre) {
                genres.push_back(genre);
            }
            while (ss >> actor) {
                cast.push_back(actor);
            }

            Movie* movie = new Movie(movieID, title, genres, director, cast, releaseDate);
            movies.push_back(movie);
        }

        file.close();
    }

    // Save movies to a file
    void saveMovies(const string& filename) {
        ofstream file(filename);
        if (!file.is_open()) {
            cerr << "Unable to open file: " << filename << endl;
            return;
        }

        for (const auto& movie : movies) {
            file << movie->getMovieID() << " "
                << movie->getTitle() << " "
                << movie->getDirector() << " "
                << movie->getReleaseDate();
            for (const auto& genre : movie->getGenres()) {
                file << " " << genre;
            }
            for (const auto& actor : movie->getCast()) {
                file << " " << actor;
            }
            file << endl;
        }

        file.close();
    }

    // Load directors from a file
    void loadDirectors(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cerr << "Unable to open file: " << filename << endl;
            return;
        }

        string name, gender;
        int directorID;
        while (file >> name >> gender >> directorID) {
            Director* director = new Director(name, gender, directorID);
            directors.push_back(director);
        }

        file.close();
    }

    // Save directors to a file
    void saveDirectors(const string& filename) {
        ofstream file(filename);
        if (!file.is_open()) {
            cerr << "Unable to open file: " << filename << endl;
            return;
        }

        for (const auto& director : directors) {
            file << director->getName() << " "
                << director->getGender() << " "
                << director->getDirectorID() << endl;
        }

        file.close();
    }

    // Load actors from a file
    void loadActors(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cerr << "Unable to open file: " << filename << endl;
            return;
        }

        string name, gender;
        int actorID;
        while (file >> name >> gender >> actorID) {
            Actor* actor = new Actor(name, gender, actorID);
            actors.push_back(actor);
        }

        file.close();
    }

    // Save actors to a file
    void saveActors(const string& filename) {
        ofstream file(filename);
        if (!file.is_open()) {
            cerr << "Unable to open file: " << filename << endl;
            return;
        }

        for (const auto& actor : actors) {
            file << actor->getName() << " "
                << actor->getGender() << " "
                << actor->getActorID() << endl;
        }

        file.close();
    }

    // Utility function to split a string by a delimiter
    static vector<string> split(const string& str, char delimiter) {
        vector<string> tokens;
        stringstream ss(str);
        string token;
        while (getline(ss, token, delimiter)) {
            tokens.push_back(token);
        }
        return tokens;
    }

    const vector<User*>& getUsers() const {
        return users;
    }

    const vector<Movie*>& getMovies() const {
        return movies;
    }

    const vector<Genre*>& getGenres() const {
        return genres;
    }

    const vector<Director*>& getDirectors() const {
        return directors;
    }

    const vector<Actor*>& getActors() const {
        return actors;
    }
};

bool isValidPassword(const string& password) {
    return password.length() >= 6;
}

// Register a new user
User* registerUser(RecommendationSystem& recSys) {
    string name, gender, email, password;
    cout << "Enter your name: ";
    cin >> name;
    cout << "Enter your gender: ";
    cin >> gender;
    cout << "Enter your email: ";
    cin >> email;
    cout << "Enter your password: ";
    cin >> password;

    User* user = new User(name, gender, email, password);

    vector<string> genres, actors, directors;
    string input;

    cout << "\n\nEnter your favorite genres (comma-separated): ";
    cin.ignore();
    getline(cin, input);
    genres = RecommendationSystem::split(input, ',');
    user->setGenres(genres);

    cout << "Enter your favorite actors (comma-separated): ";
    getline(cin, input);
    actors = RecommendationSystem::split(input, ',');
    user->setActors(actors);

    cout << "Enter your favorite directors (comma-separated): ";
    getline(cin, input);
    directors = RecommendationSystem::split(input, ',');
    user->setDirectors(directors);

    recSys.addUser(user);
    cout << "Registration successful!" << endl;

    return nullptr;
}


// Login an existing user
User* loginUser(RecommendationSystem& recSys) {
    string email, password;
    cout << "Enter your email: ";
    cin >> email;
    cout << "Enter your password: ";
    cin >> password;

    for (const auto& user : recSys.getUsers()) {
        if (user->getEmail() == email && user->getPassword() == password) {
            menu(user);
        }
    }

    cout << "Invalid email or password!" << endl;
    return nullptr;
}

// View user profile
void viewProfile(const User& user) {
    cout << "Name: " << user.getName() << endl;
    cout << "Gender: " << user.getGender() << endl;
    cout << "Email: " << user.getEmail() << endl;
    cout << "Favorite Genres: ";
    for (const auto& genre : user.getGenres()) {
        cout << genre << " ";
    }
    cout << endl;
    cout << "Favorite Actors: ";
    for (const auto& actor : user.getActors()) {
        cout << actor << " ";
    }
    cout << endl;
    cout << "Favorite Directors: ";
    for (const auto& director : user.getDirectors()) {
        cout << director << " ";
    }
    cout << endl;

    cout << "\n watchlist: ";
    user.getWatchlist();
}

void rateMovie(User* , RecommendationSystem& );

ostream& operator<<(ostream& os, const vector<string>& vec) {
    for (const auto& str : vec) {
        os << str << " ";
    }
    return os;
}

// Display movie recommendations for a user
void displayRecommendations(User& user, RecommendationSystem& recSys) {
    vector<Movie*> recommendations = recSys.generateRecommendations(user);
    Movie* movie24;
    int i, choice, choice1, movieNum;

    User* loggeduser = &user;

    while(choice == 1){
     clearScreen();
    if (recommendations.empty()) {
        cout << "No recommendations available based on your preferences." << endl;
    } else {
        cout << "Recommended Movies:" << endl;
        for (const auto& movie12 : recommendations) {
            i = 1;
            cout << i << "- " << movie12->getTitle() << " (" << movie12->getReleaseDate() << ") - Avg. Rating: " << movie12->getAverageRating() << endl;           
            ++i;
        }

        movie24 = recommendations.at(i-1);

        cout << "\n\n1. change Recommendations" << endl;
        cout << "2. choose movie" << endl;
        cout << "3. menu" << endl;
        cout << "Choose an option: ";

        cin >> choice;

        if(choice == 2){
            cout << "\n\nmovie number: ";
            cin >> movieNum;
            clearScreen();
            cout << movie24->getTitle() << " (" << movie24->getReleaseDate() << ") - \nAvg. Rating: " << movie24->getAverageRating() << "\nDirector: ";
            cout << movie24->getDirector() << "\nGenres: " << movie24->getGenres() << "\nCast: " << movie24->getCast() << endl;

            cout << "1. Add to watchlist" << endl;
            cout << "2. Rate movie" << endl;
            cout << "3. menu" << endl;
            cout << "Choose an option: ";

            cin >> choice1;

                if(choice1)
                 user.addToWatchlist(movie24->getMovieID());
                 else if (choice1 == 2)
                 rateMovie(&user, recSys);
                 else if(choice1 == 3)
                 menu(loggeduser);
                 else
                 cout << "Invalid choice! Please choose a valid option." << endl;

        }else if(choice == 3)
        menu(loggeduser);
        else
        cout << "Invalid choice! Please choose a valid option." << endl;
    }
    }
    
}

// Rate a movie
void rateMovie(User* user, RecommendationSystem& recSys) {
    int movieID, rating;
    cout << "Enter movie ID to rate: ";
    cin >> movieID;
    cout << "Enter your rating (1-5): ";
    cin >> rating;

    if (rating < 1 || rating > 5) {
        cout << "Invalid rating! Please enter a rating between 1 and 5." << endl;
        return;
    }

    user->rateMovie(movieID, rating);
    for (auto& movie : recSys.getMovies()) {
        if (movie->getMovieID() == movieID) {
            movie->addRating(movie->getMovieID(), rating); // Assuming email is used as a unique identifier
            cout << "Rating added successfully!" << endl;
            return;
        }
    }
    cout << "Movie not found!" << endl;
}

//Update a user's preferences
void updateUserPreferences(User* user) {
    vector<string> genres, actors, directors;
    string input;

    cout << "Enter your new favorite genres (comma-separated): ";
    getline(cin, input);
    genres = RecommendationSystem::split(input, ',');

    cout << "Enter your new favorite actors (comma-separated): ";
    getline(cin, input);
    actors = RecommendationSystem::split(input, ',');

    cout << "Enter your new favorite directors (comma-separated): ";
    getline(cin, input);
    directors = RecommendationSystem::split(input, ',');

    user->updatePreferences(genres, actors, directors);
    cout << "Preferences updated successfully!" << endl;
}

void clearScreen() {
    #ifdef _WIN32
        system("cls");  // Windows command to clear the screen
    #else
        system("clear");
    #endif
}

int menu(User* loggedInUser = nullptr)
{
RecommendationSystem recSys;

        cout << "1. Display Recommendations" << endl;
        cout << "2. View Profile" << endl;
        cout << "3. logout" << endl;
        cout << "Choose an option: ";

        int choice;
        cin >> choice;
        switch (choice) {
        case 1:
            clearScreen();
            displayRecommendations(*loggedInUser, recSys);
            break;
        case 2:
            clearScreen();
            viewProfile(*loggedInUser);

            cout << "\n1. Update Preferences" << endl;
            cout << "2. Return menu" << endl;
            cin >> choice;

            if(choice){
            clearScreen();
            updateUserPreferences(loggedInUser);
            }else if(choice == 2){
            clearScreen();
            menu(loggedInUser);
            }else
            cout << "Invalid choice! Please choose a valid option." << endl;
            break;
        case 3:
           // Save data before exiting
            recSys.saveUsers("users.txt");
            recSys.saveMovies("movies.txt");
            recSys.saveDirectors("directors.txt");
            recSys.saveActors("actors.txt");
            cout << "Goodbye!" << endl;
          loginpage();
        default:
            cout << "Invalid choice! Please choose a valid option." << endl;
        }
    return choice;
}

int loginpage()
{
 RecommendationSystem recSys;

    // Load existing data
    recSys.loadUsers("users.txt");
    recSys.loadMovies("movies.txt");
    recSys.loadDirectors("directors.txt");
    recSys.loadActors("actors.txt");

    User* loggedInUser = nullptr;
    
    cout << "1. Register" << endl;
        cout << "2. Login" << endl;

        int choice;
        cin >> choice;

        switch (choice) {
        case 1:
            clearScreen();
            loggedInUser = registerUser(recSys);
            loginpage();
            break;
        case 2:
            clearScreen();
            loggedInUser = loginUser(recSys);
            break;
        case 3:
         // Save data before exiting
            recSys.saveUsers("users.txt");
            recSys.saveMovies("movies.txt");
            recSys.saveDirectors("directors.txt");
            recSys.saveActors("actors.txt");
            cout << "Goodbye!" << endl;
            return 0;
        default:
            cout << "Invalid choice! Please choose a valid option." << endl;
        }
    return choice;
}

int main() {
    loginpage();
    system("pause");
    return 0;
}
